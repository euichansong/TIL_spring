package jpashop.jpashop.domain;

public enum DeliveyStatus {
    READY, COMP
}
