package jpashop.jpashop.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
